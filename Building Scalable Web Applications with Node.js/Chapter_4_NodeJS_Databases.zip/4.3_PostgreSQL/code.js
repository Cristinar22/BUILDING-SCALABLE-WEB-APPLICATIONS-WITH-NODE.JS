
const { Client } = require('pg');

const client = new Client({
  user: 'yourUsername',
  host: 'localhost',
  database: 'mydatabase',
  password: 'yourPassword',
  port: 5432
});

client.connect()
  .then(() => console.log('PostgreSQL connected'))
  .catch((err) => console.log('Error: ' + err));

const query = 'INSERT INTO users(name, email) VALUES($1, $2) RETURNING *';
const values = ['John Doe', 'john@example.com'];

client.query(query, values)
  .then(res => console.log(res.rows[0]))
  .catch(err => console.log(err));

client.query('SELECT * FROM users')
  .then(res => console.log(res.rows))
  .catch(err => console.log(err));

const query = 'UPDATE users SET email = $1 WHERE name = $2 RETURNING *';
const values = ['john.doe@example.com', 'John Doe'];

client.query(query, values)
  .then(res => console.log(res.rows[0]))
  .catch(err => console.log(err));

const query = 'DELETE FROM users WHERE name = $1';
const values = ['John Doe'];

client.query(query, values)
  .then(() => console.log('User deleted'))
  .catch(err => console.log(err));
