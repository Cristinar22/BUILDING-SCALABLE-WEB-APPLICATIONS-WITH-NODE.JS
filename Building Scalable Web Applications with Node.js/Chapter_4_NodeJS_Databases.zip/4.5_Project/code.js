
mkdir full-stack-crud
cd full-stack-crud
npm init -y
npm install express mongoose sequelize pg pg-hstore

// MongoDB for User Authentication
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/myapp', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('Error: ' + err));

// PostgreSQL for Storing Tasks
const { Client } = require('pg');
const client = new Client({ 
  user: 'yourUsername',
  host: 'localhost',
  database: 'mydatabase',
  password: 'yourPassword',
  port: 5432 
});
client.connect().then(() => console.log('PostgreSQL connected')).catch((err) => console.log('Error: ' + err));
