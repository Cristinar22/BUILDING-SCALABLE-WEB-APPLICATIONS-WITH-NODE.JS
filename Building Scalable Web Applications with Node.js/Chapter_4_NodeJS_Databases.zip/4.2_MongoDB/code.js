
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/myapp', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('Error: ' + err));

const userSchema = new mongoose.Schema({
  name: String,
  email: String
});

const User = mongoose.model('User', userSchema);

const newUser = new User({ name: 'John Doe', email: 'john@example.com' });
newUser.save()
  .then(() => console.log('User created'))
  .catch(err => console.log(err));

User.find()
  .then(users => console.log(users))
  .catch(err => console.log(err));

User.findOneAndUpdate({ name: 'John Doe' }, { email: 'john.doe@example.com' })
  .then(() => console.log('User updated'))
  .catch(err => console.log(err));

User.deleteOne({ name: 'John Doe' })
  .then(() => console.log('User deleted'))
  .catch(err => console.log(err));
