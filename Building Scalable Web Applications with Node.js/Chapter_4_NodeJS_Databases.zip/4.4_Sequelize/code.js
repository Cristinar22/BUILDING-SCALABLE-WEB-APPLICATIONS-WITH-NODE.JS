
const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize('postgres://user:password@localhost:5432/mydatabase');

try {
  await sequelize.authenticate();
  console.log('Connection has been established successfully.');
} catch (error) {
  console.error('Unable to connect to the database:', error);
}

const User = sequelize.define('User', {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  }
});

await User.create({ name: 'Jane Doe', email: 'jane@example.com' });

const users = await User.findAll();
console.log(users);

const user = await User.findOne({ where: { name: 'Jane Doe' } });
user.email = 'jane.doe@example.com';
await user.save();

const user = await User.findOne({ where: { name: 'Jane Doe' } });
await user.destroy();
