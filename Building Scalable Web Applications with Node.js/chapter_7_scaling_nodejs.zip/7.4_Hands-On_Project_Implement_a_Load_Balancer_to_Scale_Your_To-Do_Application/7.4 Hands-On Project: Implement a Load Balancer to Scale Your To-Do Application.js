
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
    res.send('Hello, To-Do App!');
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

// Cluster setup
const cluster = require('cluster');
const os = require('os');
const numCPUs = os.cpus().length;

if (cluster.isMaster) {
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork();
    }

    cluster.on('exit', (worker, code, signal) => {
        console.log(`Worker ${worker.process.pid} died`);
    });
} else {
    const express = require('express');
    const app = express();
    const port = 3000;

    app.get('/', (req, res) => {
        res.send('Hello, Load Balanced To-Do App!');
    });

    app.listen(port, () => {
        console.log(`Worker ${process.pid} running on http://localhost:${port}`);
    });
}
