
// Hands-On Project: Build a RESTful API for a To-Do List Application
const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());  // To parse JSON bodies

let todos = [
  { id: 1, task: 'Buy groceries' },
  { id: 2, task: 'Clean the house' }
];

// GET /todos - Get all to-dos
app.get('/todos', (req, res) => {
  res.json(todos);
});

// POST /todos - Add a new to-do
app.post('/todos', (req, res) => {
  const newTodo = req.body;
  newTodo.id = todos.length + 1;
  todos.push(newTodo);
  res.status(201).json(newTodo);
});

// PUT /todos/:id - Update a to-do
app.put('/todos/:id', (req, res) => {
  const todoId = parseInt(req.params.id);
  const updatedTodo = req.body;
  let todo = todos.find(t => t.id === todoId);
  if (todo) {
    todo.task = updatedTodo.task;
    res.json(todo);
  } else {
    res.status(404).json({ message: 'To-do not found' });
  }
});

// DELETE /todos/:id - Delete a to-do
app.delete('/todos/:id', (req, res) => {
  const todoId = parseInt(req.params.id);
  todos = todos.filter(t => t.id !== todoId);
  res.status(204).send();
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
