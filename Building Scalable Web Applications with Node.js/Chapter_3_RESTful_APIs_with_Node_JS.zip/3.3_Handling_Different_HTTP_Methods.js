
// Handling GET, POST, PUT, DELETE Requests

// GET Request
app.get('/todos', (req, res) => {
  res.json([
    { id: 1, task: 'Buy groceries' },
    { id: 2, task: 'Clean the house' }
  ]);
});

// POST Request
app.use(express.json());  // To parse JSON bodies
app.post('/todos', (req, res) => {
  const newTodo = req.body;
  res.status(201).json(newTodo);
});

// PUT Request
app.put('/todos/:id', (req, res) => {
  const todoId = req.params.id;
  const updatedTodo = req.body;
  res.json({ id: todoId, task: updatedTodo.task });
});

// DELETE Request
app.delete('/todos/:id', (req, res) => {
  const todoId = req.params.id;
  res.status(204).send();
});
