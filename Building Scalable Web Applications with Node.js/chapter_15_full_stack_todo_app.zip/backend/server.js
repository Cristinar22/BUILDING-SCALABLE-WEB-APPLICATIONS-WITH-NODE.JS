
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());  // Enable CORS
app.use(express.json());  // For parsing JSON bodies

// In-memory array to store to-do items
let todos = [
  { id: 1, task: 'Learn Node.js' },
  { id: 2, task: 'Build a full-stack app' },
];

// Get all To-Dos
app.get('/todos', (req, res) => {
  res.json(todos);
});

// Add a new To-Do
app.post('/todos', (req, res) => {
  const { task } = req.body;
  const newTodo = { id: todos.length + 1, task };
  todos.push(newTodo);
  res.status(201).json(newTodo);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
        