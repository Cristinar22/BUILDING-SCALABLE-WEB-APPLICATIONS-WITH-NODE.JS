// Uninstall Moment.js
npm uninstall moment