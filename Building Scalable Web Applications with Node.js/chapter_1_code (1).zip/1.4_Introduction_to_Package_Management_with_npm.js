// Install Moment.js
npm install moment

// app.js
const moment = require('moment');
console.log(moment().format('MMMM Do YYYY, h:mm:ss a'));