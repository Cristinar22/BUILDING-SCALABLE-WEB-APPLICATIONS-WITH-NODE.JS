const bcrypt = require('bcryptjs');

const users = [];  // In-memory user store (replace with a database in production)

function registerUser(username, password) {
  const hashedPassword = bcrypt.hashSync(password, 10);  // Hashing password
  const newUser = { username, password: hashedPassword };
  users.push(newUser);
  return newUser;
}

function findUserByUsername(username) {
  return users.find(user => user.username === username);
}