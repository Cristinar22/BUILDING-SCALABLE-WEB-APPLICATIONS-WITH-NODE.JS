const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

// Set up Passport.js to use the local strategy for authentication
passport.use(new LocalStrategy(
  (username, password, done) => {
    const user = findUserByUsername(username);
    if (!user) return done(null, false, { message: 'Incorrect username' });

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) return done(null, false, { message: 'Incorrect password' });

    return done(null, user);
  }
));

// Serialize user (store the user in the session)
passport.serializeUser((user, done) => {
  done(null, user.username);
});

// Deserialize user (retrieve the user from session)
passport.deserializeUser((username, done) => {
  const user = findUserByUsername(username);
  done(null, user);
});