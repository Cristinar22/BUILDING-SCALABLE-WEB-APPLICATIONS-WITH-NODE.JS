const jwt = require('jsonwebtoken');

// Secret key for signing the JWT
const secretKey = 'your-secret-key';

// Function to generate a JWT
function generateToken(user) {
  const payload = {
    userId: user._id,  // Including the user ID in the token payload
  };

  const token = jwt.sign(payload, secretKey, { expiresIn: '1h' });  // Token expires in 1 hour
  return token;
}