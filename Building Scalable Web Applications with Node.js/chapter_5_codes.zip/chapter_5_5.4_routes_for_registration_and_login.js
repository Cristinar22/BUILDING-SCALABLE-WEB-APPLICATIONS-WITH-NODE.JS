const express = require('express');
const jwt = require('jsonwebtoken');
const passport = require('passport');
const User = require('./models/User');

const app = express();
app.use(express.json());
app.use(passport.initialize());
app.use(passport.session());

// Registration route
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const user = new User({ username, password });
  await user.save();
  res.status(201).json({ message: 'User registered successfully' });
});

// Login route with JWT generation
app.post('/login', passport.authenticate('local', { session: false }), (req, res) => {
  const token = jwt.sign({ userId: req.user._id }, 'secretkey', { expiresIn: '1h' });
  res.json({ message: 'Logged in successfully', token });
});