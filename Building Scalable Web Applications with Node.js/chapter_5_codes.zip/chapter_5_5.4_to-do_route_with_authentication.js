// Create To-Do item (Authenticated)
app.post('/todos', authenticateToken, (req, res) => {
  // Only proceed if authenticated
  // Add the to-do item to the user's collection
  res.json({ message: 'To-Do created successfully' });
});