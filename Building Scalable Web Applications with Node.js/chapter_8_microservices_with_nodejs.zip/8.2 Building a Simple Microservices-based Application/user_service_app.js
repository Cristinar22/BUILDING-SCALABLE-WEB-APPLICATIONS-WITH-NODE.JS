
const express = require('express');
const app = express();
const port = 3001;

// Fake database
const users = [];

app.use(express.json());

// Endpoint to create a new user
app.post('/users', (req, res) => {
  const { username, email } = req.body;
  const user = { id: users.length + 1, username, email };
  users.push(user);
  res.status(201).json(user);
});

// Endpoint to get a user by ID
app.get('/users/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).send('User not found');
  res.json(user);
});

app.listen(port, () => {
  console.log(`User service running on http://localhost:${port}`);
});
