
const express = require('express');
const axios = require('axios');
const app = express();
const port = 3002;

// Fake database for tasks
const tasks = [];

app.use(express.json());

// Endpoint to create a task for a user
app.post('/tasks', (req, res) => {
  const { userId, description } = req.body;
  const task = { id: tasks.length + 1, userId, description };
  tasks.push(task);
  res.status(201).json(task);
});

// Endpoint to get tasks for a user
app.get('/tasks/:userId', async (req, res) => {
  const userId = parseInt(req.params.userId);
  const userExists = await axios.get(`http://localhost:3001/users/${userId}`);
  if (!userExists) return res.status(404).send('User not found');
  const userTasks = tasks.filter(task => task.userId === userId);
  res.json(userTasks);
});

app.listen(port, () => {
  console.log(`Task service running on http://localhost:${port}`);
});
