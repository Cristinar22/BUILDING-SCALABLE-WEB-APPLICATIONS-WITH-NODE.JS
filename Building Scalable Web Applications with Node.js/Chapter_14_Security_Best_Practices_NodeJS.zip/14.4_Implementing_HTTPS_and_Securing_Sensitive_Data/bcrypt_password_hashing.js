// Hash a password using bcryptjs
const bcrypt = require('bcryptjs');

bcrypt.hash('user_password', 10, (err, hashedPassword) => {
  // Store hashedPassword in your database
});

bcrypt.compare('user_password', hashedPassword, (err, isMatch) => {
  if (isMatch) {
    console.log('Password matches');
  } else {
    console.log('Invalid password');
  }
});