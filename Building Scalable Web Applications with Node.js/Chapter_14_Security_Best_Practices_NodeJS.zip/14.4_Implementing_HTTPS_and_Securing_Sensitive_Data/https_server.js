// Enable HTTPS in Node.js application
const https = require('https');
const fs = require('fs');
const express = require('express');

const app = express();
const options = {
  cert: fs.readFileSync('cert.pem'),
  key: fs.readFileSync('key.pem'),
};

https.createServer(options, app).listen(3000, () => {
  console.log('Secure server running on https://localhost:3000');
});