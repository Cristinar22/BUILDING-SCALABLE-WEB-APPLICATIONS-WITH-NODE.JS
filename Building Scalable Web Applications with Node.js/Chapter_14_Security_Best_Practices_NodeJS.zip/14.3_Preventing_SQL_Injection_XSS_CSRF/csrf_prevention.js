// Use CSRF Tokens with Express and csurf middleware
const csrf = require('csurf');
const csrfProtection = csrf({ cookie: true });

app.post('/form', csrfProtection, (req, res) => {
  res.send(`CSRF token is ${req.csrfToken()}`);
});