// Sanitize User Input using DOMPurify
const DOMPurify = require('dompurify');

function sanitizeInput(input) {
  return DOMPurify.sanitize(input);
}