// Example: Input Validation using Joi
const Joi = require('joi');

const userSchema = Joi.object({
  username: Joi.string().alphanum().min(3).max(30).required(),
  password: Joi.string().min(8).required(),
});

function validateUserInput(input) {
  const { error } = userSchema.validate(input);
  if (error) {
    throw new Error('Invalid input');
  }
}