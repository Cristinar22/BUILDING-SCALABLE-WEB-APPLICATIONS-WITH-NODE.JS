// Use Helmet in Your App
const express = require('express');
const helmet = require('helmet');
const app = express();

app.use(helmet());  // Apply security headers to all requests