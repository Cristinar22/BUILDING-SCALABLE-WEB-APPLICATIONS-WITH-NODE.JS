
const start = Date.now();

// Your function or operation
someHeavyOperation();

const duration = Date.now() - start;
console.log(`Operation took ${duration}ms`);
