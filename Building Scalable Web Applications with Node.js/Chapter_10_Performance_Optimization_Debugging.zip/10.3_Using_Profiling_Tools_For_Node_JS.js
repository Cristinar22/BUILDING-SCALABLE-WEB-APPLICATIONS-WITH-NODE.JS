
# Start the Profiler
node --inspect app.js
# Open Chrome DevTools at chrome://inspect and record the profile.
