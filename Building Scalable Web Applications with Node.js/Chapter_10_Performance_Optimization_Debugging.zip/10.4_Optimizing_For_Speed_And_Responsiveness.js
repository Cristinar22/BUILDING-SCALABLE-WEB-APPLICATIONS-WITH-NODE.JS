
// Example of Asynchronous Programming
const fs = require('fs').promises;

async function readFile() {
  try {
    const data = await fs.readFile('someFile.txt', 'utf8');
    console.log(data);
  } catch (err) {
    console.error(err);
  }
}

// Optimize Database Queries
CREATE INDEX idx_user_email ON users(email);

// Example of Worker Threads for Offloading CPU-bound Tasks
const { Worker, isMainThread, parentPort } = require('worker_threads');

if (isMainThread) {
  const worker = new Worker(__filename);
  worker.on('message', (message) => console.log(message));
  worker.postMessage('start');
} else {
  parentPort.on('message', (message) => {
    if (message === 'start') {
      parentPort.postMessage('Heavy task completed');
    }
  });
}

// Example of Caching with Redis
const redis = require('redis');
const client = redis.createClient();

client.setex('someKey', 3600, 'cachedValue');  // Store in cache for 1 hour

// Example of Compression Middleware
const compression = require('compression');
app.use(compression());
