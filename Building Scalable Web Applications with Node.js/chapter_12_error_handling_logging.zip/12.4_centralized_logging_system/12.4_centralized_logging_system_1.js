const winston = require('winston');
const logger = winston.createLogger({
  level: 'info',  // Log level: info, warn, error, debug
  format: winston.format.simple(),  // Log format
  transports: [
    new winston.transports.Console({ format: winston.format.simple() }),
    new winston.transports.File({ filename: 'app.log' })
  ]
});

// Using the logger
logger.info('Application started');
logger.error('Something went wrong');