app.get('/tasks', async (req, res, next) => {
  try {
    const tasks = await getTasksFromDatabase();  // Assuming this is an async call
    res.json(tasks);
  } catch (err) {
    logger.error('Failed to fetch tasks:', err.message);
    next(err);  // Pass error to error-handling middleware
  }
});