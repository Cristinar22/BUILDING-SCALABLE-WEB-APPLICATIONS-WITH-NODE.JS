async function getUserData(userId) {
  try {
    const response = await fetchDataFromDatabase(userId);  // Assume this is an async call
    return response;
  } catch (err) {
    console.error('Error retrieving user data:', err.message);
    throw new Error('Failed to get user data');
  }
}