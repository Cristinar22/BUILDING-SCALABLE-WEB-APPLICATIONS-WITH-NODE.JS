async function processData() {
  try {
    const userData = await fetchDataFromDatabase(123);
    const processedData = await processData(userData);
    return processedData;
  } catch (err) {
    console.error('Error processing data:', err.message);
  }
}