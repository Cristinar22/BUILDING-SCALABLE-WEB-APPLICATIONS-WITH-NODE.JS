app.get('/user/:id', (req, res) => {
  const user = getUserFromDatabase(req.params.id);  // This is a mock function
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  res.json(user);
});