async function fetchData() {
  try {
    const data = await fetchFromApi('https://api.example.com/data');  // Assume fetchFromApi is an async function
    console.log(data);
  } catch (err) {
    console.error('Failed to fetch data:', err.message);
  }
}