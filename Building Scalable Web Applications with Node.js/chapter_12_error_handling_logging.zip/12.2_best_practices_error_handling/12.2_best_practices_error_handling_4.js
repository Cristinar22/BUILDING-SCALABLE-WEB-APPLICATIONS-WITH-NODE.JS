class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
    this.statusCode = 400;
  }
}
function validateData(data) {
  if (!data.name) {
    throw new ValidationError('Name is required');
  }
}
try {
  validateData({});  // This will throw an error
} catch (err) {
  if (err instanceof ValidationError) {
    console.log(`${err.name}: ${err.message}`);
  }
}