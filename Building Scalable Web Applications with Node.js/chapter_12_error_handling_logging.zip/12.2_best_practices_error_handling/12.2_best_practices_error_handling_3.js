app.use((err, req, res, next) => {
  console.error(err.stack);  // Log the error
  res.status(500).send('Something went wrong!');  // Send a generic error message
});