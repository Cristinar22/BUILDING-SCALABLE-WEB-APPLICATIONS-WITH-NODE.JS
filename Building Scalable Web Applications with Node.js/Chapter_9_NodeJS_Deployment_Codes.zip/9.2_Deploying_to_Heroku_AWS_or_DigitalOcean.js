
# Heroku Deployment Commands
heroku create
git init
git add .
git commit -m "Initial commit"
git push heroku master
    