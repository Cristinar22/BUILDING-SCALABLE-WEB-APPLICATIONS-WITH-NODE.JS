
const chai = require('chai');
const expect = chai.expect;
const calculator = require('../calculator');

describe('Calculator', () => {
  describe('#add()', () => {
    it('should return the sum of two numbers', () => {
      const result = calculator.add(2, 3);
      expect(result).to.equal(5);
    });
    
    it('should return a negative number when adding a negative number', () => {
      const result = calculator.add(-2, 3);
      expect(result).to.equal(1);
    });
  });
});
    