
const request = require('supertest');
const app = require('../app');  // Import your Express app

describe('Tasks API', () => {

  it('should fetch all tasks', async () => {
    const response = await request(app).get('/tasks');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('tasks');
  });

  it('should create a new task', async () => {
    const newTask = { title: 'Learn Jest', completed: false };
    const response = await request(app).post('/tasks').send(newTask);
    expect(response.status).toBe(201);
    expect(response.body.title).toBe('Learn Jest');
  });

  it('should update an existing task', async () => {
    const updatedTask = { title: 'Learn Jest - Updated', completed: true };
    const response = await request(app).put('/tasks/1').send(updatedTask);
    expect(response.status).toBe(200);
    expect(response.body.title).toBe('Learn Jest - Updated');
  });

  it('should delete a task', async () => {
    const response = await request(app).delete('/tasks/1');
    expect(response.status).toBe(204);  // No content on successful delete
  });

});
    