
function addTodo(todoList, todo) {
  todoList.push(todo);
  return todoList;
}

module.exports = { addTodo };
    