
const todo = require('./todo');

describe('To-Do List', () => {
  let todoList;

  beforeEach(() => {
    todoList = [];  // Reset the list before each test
  });

  test('should add a new todo to the list', () => {
    const result = todo.addTodo(todoList, 'Learn Node.js');
    expect(result).toEqual(['Learn Node.js']);
  });

  test('should add multiple todos to the list', () => {
    todo.addTodo(todoList, 'Learn Node.js');
    todo.addTodo(todoList, 'Learn Jest');
    expect(todoList).toEqual(['Learn Node.js', 'Learn Jest']);
  });
});
    