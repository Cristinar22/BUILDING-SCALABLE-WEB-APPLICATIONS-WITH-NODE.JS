
    async function fetchData() {
      try {
        let response = await fetch('https://api.example.com');
        let data = await response.json();
        console.log(data);
      } catch (error) {
        console.log("Error:", error);
      }
    }
    fetchData();
    