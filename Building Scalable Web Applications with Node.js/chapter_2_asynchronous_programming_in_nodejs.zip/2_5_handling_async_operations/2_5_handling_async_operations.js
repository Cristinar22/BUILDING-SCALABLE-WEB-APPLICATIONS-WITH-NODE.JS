
    const fs = require('fs').promises;

    async function readFiles() {
      try {
        const file1 = await fs.readFile('file1.txt', 'utf8');
        const file2 = await fs.readFile('file2.txt', 'utf8');
        console.log(file1, file2);
      } catch (error) {
        console.error('Error reading files:', error);
      }
    }

    readFiles();
    