
    // Example for Event Loop
    setTimeout(() => {
        console.log("Task 1");
    }, 1000);

    setTimeout(() => {
        console.log("Task 2");
    }, 0);
    