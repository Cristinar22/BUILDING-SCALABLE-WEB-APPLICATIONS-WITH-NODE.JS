
    const fs = require('fs').promises;

    async function readFilesConcurrently() {
      try {
        const files = await Promise.all([
          fs.readFile('file1.txt', 'utf8'),
          fs.readFile('file2.txt', 'utf8'),
          fs.readFile('file3.txt', 'utf8')
        ]);
        console.log(files);
      } catch (error) {
        console.error('Error reading files:', error);
      }
    }

    readFilesConcurrently();
    