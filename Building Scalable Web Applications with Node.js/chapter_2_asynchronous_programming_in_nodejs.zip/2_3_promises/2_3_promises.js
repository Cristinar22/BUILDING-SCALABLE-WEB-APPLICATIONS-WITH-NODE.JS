
    const myPromise = new Promise((resolve, reject) => {
      const success = true;
      if (success) {
        resolve("Operation was successful!");
      } else {
        reject("There was an error!");
      }
    });

    myPromise.then(result => {
      console.log(result);
    }).catch(error => {
      console.error(error);
    });

    const getDataFromAPI = () => new Promise(resolve => setTimeout(() => resolve("API Data"), 1000));
    const processData = data => new Promise(resolve => setTimeout(() => resolve(data + " Processed"), 1000));
    const saveData = data => new Promise(resolve => setTimeout(() => resolve(data + " Saved"), 1000));

    getDataFromAPI()
      .then(response => processData(response))
      .then(processedData => saveData(processedData))
      .then(() => console.log("All tasks completed successfully!"))
      .catch(error => console.error("Error occurred:", error));
    